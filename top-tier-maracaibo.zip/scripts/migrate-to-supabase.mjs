#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js'
import { GENRES } from '../lib/genres.ts'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseKey)

async function migrateData() {
  console.log('🚀 Starting data migration to Supabase...')

  try {
    // Clear existing data
    console.log('🧹 Clearing existing data...')
    await supabase.from('artists').delete().neq('id', '')
    await supabase.from('genres').delete().neq('id', '')

    // Insert genres and artists
    console.log('📝 Inserting genres and artists...')

    for (const genre of GENRES) {
      // Insert genre
      const { error: genreError } = await supabase.from('genres').insert({
        id: genre.id,
        name: genre.name,
        emoji: genre.emoji,
      })

      if (genreError) {
        console.error(`❌ Error inserting genre ${genre.name}:`, genreError)
        continue
      }

      console.log(`✅ Inserted genre: ${genre.name}`)

      // Insert artists for this genre
      for (const artist of genre.artistList) {
        const { error: artistError } = await supabase.from('artists').insert({
          id: `${genre.id}-${artist.name}`,
          genre_id: genre.id,
          name: artist.name,
          songs: artist.songs,
          mp3_mb: artist.mp3Mb,
          mp4_mb: artist.mp4Mb,
        })

        if (artistError) {
          console.error(`❌ Error inserting artist ${artist.name}:`, artistError)
          continue
        }

        console.log(`  ✅ Inserted artist: ${artist.name}`)
      }
    }

    console.log('🎉 Data migration completed successfully!')
  } catch (error) {
    console.error('❌ Migration failed:', error)
    process.exit(1)
  }
}

migrateData()
