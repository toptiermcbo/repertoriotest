import { read, utils } from 'xlsx';
import fs from 'fs';

const filePath = 'data/GENEROS-y-ARTISTAS-30ba3b.xlsx';
const workbook = read(fs.readFileSync(filePath));

console.log('Sheet names:', workbook.SheetNames);

workbook.SheetNames.forEach(sheetName => {
  console.log(`\n\n=== SHEET: ${sheetName} ===`);
  const worksheet = workbook.Sheets[sheetName];
  const data = utils.sheet_to_json(worksheet);
  console.log(JSON.stringify(data.slice(0, 30), null, 2));
});
