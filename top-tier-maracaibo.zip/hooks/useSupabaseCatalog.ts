import { useEffect, useState } from 'react'
import { fetchGenresFromDB, fetchArtistsByGenreFromDB, GenreRow, ArtistRow } from '@/lib/supabase-client'
import { GENRES } from '@/lib/genres'

interface TransformedGenre {
  id: string
  name: string
  emoji: string
  artists: number
  totalSizeMb: {
    mp3: number
    mp4: number
  }
  artistList: TransformedArtist[]
}

interface TransformedArtist {
  name: string
  songs: number
  mp3Mb: number
  mp4Mb: number
}

export function useSupabaseCatalog() {
  const [genres, setGenres] = useState<TransformedGenre[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let isMounted = true

    async function loadCatalog() {
      try {
        setLoading(true)
        setError(null)

        // Try to load from Supabase
        const genreRows = await fetchGenresFromDB()

        if (!genreRows || genreRows.length === 0) {
          // Fall back to local GENRES if Supabase is empty
          console.log('[v0] Supabase empty, using local catalog')
          if (isMounted) {
            setGenres(GENRES as any)
          }
          return
        }

        // Load artists for each genre
        const transformedGenres: TransformedGenre[] = []

        for (const genreRow of genreRows) {
          const artists = await fetchArtistsByGenreFromDB(genreRow.id)

          const artistList = artists.map((a) => ({
            name: a.name,
            songs: a.songs,
            mp3Mb: a.mp3_mb,
            mp4Mb: a.mp4_mb,
          }))

          const totalMp3 = artistList.reduce((sum, a) => sum + a.mp3Mb, 0)
          const totalMp4 = artistList.reduce((sum, a) => sum + a.mp4Mb, 0)

          transformedGenres.push({
            id: genreRow.id,
            name: genreRow.name,
            emoji: genreRow.emoji,
            artists: artistList.length,
            totalSizeMb: {
              mp3: totalMp3,
              mp4: totalMp4,
            },
            artistList,
          })
        }

        if (isMounted) {
          setGenres(transformedGenres.sort((a, b) => a.name.localeCompare(b.name, 'es')))
        }
      } catch (err) {
        console.error('[v0] Error loading catalog from Supabase:', err)
        // Fall back to local catalog
        if (isMounted) {
          setGenres(GENRES as any)
          setError('Using local catalog')
        }
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    loadCatalog()

    return () => {
      isMounted = false
    }
  }, [])

  return { genres, loading, error }
}
