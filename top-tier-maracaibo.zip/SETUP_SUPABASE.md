# Configuración de Supabase - Repertorio Musical

Esta guía te explica cómo configurar la base de datos de Supabase para que el catálogo de música funcione con sincronización en tiempo real.

## 1. Variables de Entorno

Las siguientes variables de entorno ya están configuradas automáticamente en tu proyecto Vercel:

```
NEXT_PUBLIC_SUPABASE_URL=           # URL del proyecto Supabase
NEXT_PUBLIC_SUPABASE_ANON_KEY=      # Clave pública anon de Supabase
SUPABASE_SERVICE_ROLE_KEY=          # Clave secreta para operaciones del servidor
```

**✅ No necesitas hacer nada** - Vercel las configura automáticamente cuando conectas la integración Supabase.

## 2. Tablas en la Base de Datos

Las tablas ya fueron creadas automáticamente con la migración:

### Tabla `genres`
```sql
- id (TEXT, PRIMARY KEY)
- name (TEXT, UNIQUE)
- emoji (TEXT)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
```

### Tabla `artists`
```sql
- id (TEXT, PRIMARY KEY)
- genre_id (TEXT, FOREIGN KEY)
- name (TEXT)
- songs (INTEGER)
- mp3_mb (INTEGER)
- mp4_mb (INTEGER)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
```

## 3. Migrar Datos Locales a Supabase

### Opción A: Usar la Interfaz Web (Recomendado)

1. Abre tu aplicación en el navegador
2. Navega a `/setup`
3. Haz clic en "🚀 Migrar datos ahora"
4. Espera a que se complete la migración

### Opción B: Script Manual

Si prefieres usar Node.js:

```bash
# Instala las dependencias necesarias
pnpm install

# Ejecuta el script de migración
node scripts/migrate-to-supabase.mjs
```

## 4. Sincronización en Tiempo Real

### Cómo Funciona:

1. **Escritura de Datos:** Cuando el administrador edita, agrega o elimina un artista/género en el panel admin, se guarda en Supabase.

2. **Lectura de Datos:** Cada vez que un cliente accede a la página, la aplicación lee los datos de Supabase automáticamente.

3. **Fallback Local:** Si Supabase no está disponible, la aplicación usa el catálogo local para no romper la experiencia.

### Archivos Relevantes:

- **`lib/supabase-client.ts`** - Cliente de Supabase y funciones de lectura
- **`lib/supabase-admin.ts`** - Funciones de escritura/actualización (usadas solo en admin panel)
- **`hooks/useSupabaseCatalog.ts`** - Hook React que carga datos de Supabase
- **`components/admin-panel.tsx`** - Panel de administración que usa Supabase
- **`components/music-catalog.tsx`** - Catálogo principal que usa Supabase

## 5. Panel de Administración

El panel de administración ahora:

✅ **Guarda los cambios directamente en Supabase**
✅ **Recarga automáticamente los datos después de cada cambio**
✅ **Funciona para todos los dispositivos (no solo localStorage)**
✅ **Permite editar/agregar/eliminar géneros y artistas**

### Acceso al Panel:

1. Haz clic en el icono de engranaje (⚙️) en la esquina inferior derecha
2. Ingresa el PIN: `3060`
3. Ahora puedes administrar el catálogo

## 6. Pruebas de Funcionamiento

### Test 1: Crear un Nuevo Género
1. Accede al panel admin
2. En "Agregar Nuevo Género", ingresa:
   - Emoji: 🎸
   - Nombre: Rock Nuevo
3. Haz clic en "Agregar Género"
4. Recarga la página en otra pestaña - deberías ver el género
5. Ingresa a otro dispositivo - también verá el género

### Test 2: Editar un Artista
1. En el panel admin, expande un género
2. Haz clic en el lápiz azul de un artista
3. Cambia el nombre a "Nombre Nuevo"
4. Haz clic en "Guardar"
5. Recarga la página - verás el nombre actualizado

### Test 3: Eliminar un Artista
1. En el panel admin, expande un género
2. Haz clic en la basura roja de un artista
3. Confirma la eliminación
4. Recarga la página - el artista desaparecerá

## 7. Estructura de Carpetas

```
proyecto/
├── lib/
│   ├── supabase-client.ts      # Cliente y queries
│   ├── supabase-admin.ts       # Funciones de escritura
│   └── genres.ts               # Catálogo local (fallback)
├── hooks/
│   └── useSupabaseCatalog.ts   # Hook para cargar datos
├── components/
│   ├── admin-panel.tsx         # Panel admin con Supabase
│   └── music-catalog.tsx       # Catálogo con Supabase
├── app/
│   └── setup/
│       └── page.tsx            # Página de migración
└── scripts/
    └── migrate-to-supabase.mjs  # Script de migración
```

## 8. Solución de Problemas

### "Missing Supabase environment variables"

**Solución:** Las variables se cargaron correctamente. Este aviso aparece en tiempo de compilación pero es normal. La aplicación funcionará sin problemas en el navegador.

### Los cambios no se reflejan inmediatamente

**Solución:** Después de editar en el admin panel, recarga la página. La sincronización es automática pero requiere un refresh.

### La página muestra el catálogo local en lugar de Supabase

**Solución:** Esto es correcto. La aplicación usa Supabase si está disponible, de lo contrario usa el catálogo local. Para que Supabase funcione:
1. Asegúrate de que los datos fueron migrados (visita `/setup`)
2. Verifica que las variables de entorno estén configuradas
3. Revisa la consola del navegador para más detalles

### "Error de conexión a Supabase"

**Solución:**
1. Abre DevTools (F12) > Console
2. Verifica los mensajes de error
3. Comprueba que `NEXT_PUBLIC_SUPABASE_URL` sea correcto
4. Asegúrate de que la red tiene conexión a internet

## 9. Comandos Útiles

```bash
# Ver logs en tiempo real
pnpm dev

# Compilar para producción
pnpm build

# Ejecutar tests (si los hay)
pnpm test

# Limpar caché de compilación
rm -rf .next
pnpm build
```

## 10. Próximos Pasos

✅ **Completado:**
- Tablas creadas en Supabase
- Cliente de Supabase integrado
- Panel admin con Supabase
- Hook para sincronización
- Página de migración

📋 **Recomendaciones:**
1. Migra los datos: `/setup`
2. Prueba el panel admin en varios géneros
3. Verifica en otro dispositivo que los cambios se sincronizen
4. Prueba en producción (Vercel)

## 11. Soporte

Si encuentras problemas:

1. Revisa los logs en la consola (F12)
2. Verifica las variables de entorno en Vercel Settings > Environment Variables
3. Comprueba que Supabase esté en estado "Healthy" en el dashboard
4. Reinicia el servidor de desarrollo
