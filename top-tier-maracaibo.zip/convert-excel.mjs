import { read, utils } from 'xlsx';
import fs from 'fs';

const filePath = 'data/GENEROS-y-ARTISTAS-30ba3b.xlsx';
const workbook = read(fs.readFileSync(filePath));
const worksheet = workbook.Sheets['Hoja 1'];
const data = utils.sheet_to_json(worksheet);

const genres = {};
let currentGenre = null;

data.forEach((row, idx) => {
  const artist = row['GÉNEROS y ARTISTAS'];
  const mp3 = row['__EMPTY'];
  const files = row['__EMPTY_1'];
  const mp4 = row['__EMPTY_2'];

  // Check if it's a genre header
  if (artist && artist.includes('Genero:')) {
    currentGenre = artist.replace('Genero: ', '').trim();
    genres[currentGenre] = [];
  } else if (artist && artist !== 'Artista' && currentGenre && mp3) {
    // It's an artist entry
    genres[currentGenre].push({
      name: artist,
      mp3Mb: Math.round(mp3),
      mp4Mb: Math.round(mp4),
      songs: Math.round(files)
    });
  }
});

console.log(JSON.stringify(genres, null, 2));
